import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.util.StringTokenizer;
import java.io.PrintWriter;
public class BibCreator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner readFile = null;
		int timePrint = 1;
		int fn = 0;
		int invalid = 0;
		int valid= 0;
		System.out.println("Welcome to BibCreator!");
		String []fileName = {"Latex1.bib","Latex2.bib","Latex3.bib","Latex4.bib","Latex5.bib","Latex6.bib","Latex7.bib","Latex8.bib","Latex9.bib","Latex10.bib"}; 
		while(fn < 10) {	
			try {
				for(; fn < fileName.length; fn++) {
					readFile = new Scanner(new FileInputStream(fileName[fn]));
					readFiles(readFile, timePrint, fileName, fn);	
					timePrint ++;
					valid ++;
				}
			}catch(FileInvalidException exp) {
				System.out.println(exp.getMessage());
				fn++;
				invalid ++;
			}catch(FileNotFoundException exp) {
				System.out.println(exp.getMessage());
				System.out.println("Program will exit");
				System.exit(0);
			}
		}
		System.out.println("\nA total of " + invalid + " files were invalid and could not be processed. All others " + valid + " \"Valid\" files have been created.");
		System.out.println("End of the app");
		readFile.close();
		
		System.out.println("\nPlease enter the name of one of the files you need to review: ");
		BufferedReader rf = null;
		Scanner scanner = new Scanner(System.in);
		String file;
		file = scanner.next();
		FileReader fr = null;
		try {
				displayFileContent(fr, rf, file);
		} catch (FileInvalidException exp) {
			System.out.println(exp.getMessage());
			System.out.println("However, you will be allowed another chance to enter another file name");

			System.out.println("Enter another:");
			file = scanner.next();
			try {
				displayFileContent(fr, rf, file);
			} catch (FileInvalidException ex) {
				ex.getMessage();
				System.out.println("Program will terminate.");
				System.exit(0);
				
			}catch(IOException e) {
				System.out.println();
			}
			
		}catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("Error - Display: An error has occurred while displaying the file.");
			System.out.println("Program will terminate.");
			System.exit(0);
		}
		System.out.println("\nGoodbye! Hope you have enjooyed creating the needed files using BibCreator");
		scanner.close();

	}
	
	private static void displayFileContent(FileReader fr, BufferedReader rf, String file) throws FileInvalidException, IOException{
		// TODO Auto-generated method stub
		try {
			fr =  new FileReader(file);
			rf = new BufferedReader(fr);
		}catch(FileNotFoundException exp) {
			throw new FileInvalidException(new FileNotFoundException()); 
		}
		int info;
		info = rf.read();
		while(info != -1) {
			System.out.print((char)info);
			info = rf.read();	
		}
		rf.close();
	}
		
	public static void readFiles(Scanner readFile,int timePrint, String []fileName, int fn) throws FileNotFoundException, FileInvalidException {
		
		String month="";
		String author = "";
		String doi = "";
		String journal = "";
		String year = "";
		String title = "";
		String vol = "";
		String num = "";
		String pages = "";
		boolean copyJournal = false;
		boolean flag = false;
		boolean copyTitle = false;
		String ieee = "IEEE" + (fn + 1) + ".json";
		
		
		String line;
		StringTokenizer str;
		while(readFile.hasNext()) {
			
			line = readFile.next();
			str = new StringTokenizer(line);
			String s2 = str.nextToken();
				
			if(s2.startsWith("month={") && s2.endsWith("},")) {
				month += s2;
			}
			
			if(s2.startsWith("author={") || flag == true) {
				if(flag == true){
					if(s2.equals("and")) {
						s2 = " * ";
					}
					author += s2;
				}
				flag = true;
				if(s2.startsWith("author={")) {
					author += s2.substring(8);
				}
				if(s2.endsWith("},")) {
					author += ",";
					flag = false;
				}	
			}
			if(s2.startsWith("journal={") || copyJournal == true) {
				copyJournal = true;
				journal += s2 + " ";
				if(s2.endsWith("},")) {
					journal += ",";
					copyJournal = false;
				}				
			}
			
			if(s2.startsWith("doi={") && s2.endsWith("},")) {
				doi += s2 + ",";
			}
			
			if(s2.startsWith("year={") && s2.endsWith("},")) {
				year += s2 + ",";
			}
			
			if(s2.startsWith("title={") || copyTitle == true) {
				copyTitle = true;
				title += s2 + " ";
				if(s2.endsWith("},")) {
					copyTitle = false;
				}	
				
			}
			
			if(s2.startsWith("volume={") && s2.endsWith("},")) {
				vol += s2;
			}				
			if(s2.startsWith("number={") && s2.endsWith("},")) {
				num += s2;
			}
			if(s2.startsWith("pages={") && s2.endsWith("},")) {
				pages += s2;
			}			
		}
		
		StringBuffer field = null;
		boolean error = false;
		
		if(author.contains("author={}") || journal.contains("journal={}") || doi.contains("doi={}") || 
				year.contains("year={}") || title.contains("title={}") || title.contains("title={}") || vol.contains("volume={}") 
				|| num.contains("number={}") || pages.contains("pages={}") || month.contains("month={}") ) {
			error = true;
			if(author.contains("author={}")) {
				field = new StringBuffer("author");
			}else if(journal.contains("journal={}")) {
				field = new StringBuffer("journal");
			}else if(title.contains("title={}")) {
				field = new StringBuffer("title");
			}else if(year.contains("year={}")) {
				field = new StringBuffer("year");
			}else if(vol.contains("volume={}")) {
				field = new StringBuffer("volume");
			}else if(num.contains("number={}")) {
				field = new StringBuffer("number");
			}else if(pages.contains("pages={}")) {
				field = new StringBuffer("pages");
			}else if(doi.contains("doi={}")) {
				field = new StringBuffer("doi");
			}else if(month.contains("month={}")) {
				field = new StringBuffer("month");
			}
		}
	
		if(error) {
			throw new FileInvalidException("\nError: Detected Empty Field!\n"
					+ "===========================\n"
					+ "Problem detected with input file: " + fileName[fn] + 
					"\nFile is Invalid: Field \"" + field + "\" is Empty. Proccesing stopped at this point. Other empty fields may be present as well.");
		}
		
		
		
		//retrieving info months from file.bib
		String m1 = month.replace("month={", "");
		String m2 = m1.replace("},", ",");
		StringBuffer sbm= new StringBuffer(m2);
		sbm.deleteCharAt(sbm.length() - 1);
		String finalMonth = sbm.toString();
		String [] months = finalMonth.split(",");
		//----------------------------------
		
		//retrieving info authors from file.bib
		String a = author.replaceAll("},", ".");
		StringBuffer sba = new StringBuffer(a);
		sba.deleteCharAt(sba.length() - 1);
		String finalAuthor = sba.toString();
		String[] authors = finalAuthor.split(",");
		
		//----------------------------------

		//retrieving info journals from file.bib
		String j2 = journal.replace("journal={", "");
		String j3 = j2.replace("},", "");
		StringBuffer sbj = new StringBuffer(j3);
		sbj.delete(sbj.length() - 2, sbj.length());
		String finalJ = sbj.toString();
		String [] journals = finalJ.split(",");
		//----------------------------------
		
		//retrieving info dois from file.bib
		String d1 = doi.replace("doi={", "");
		String d2 = d1.replaceAll("},", "");
		StringBuffer sbd = new StringBuffer(d2);
		sbd.deleteCharAt(sbd.length() - 1);
		String finalD = sbd.toString();
		String [] dois = finalD.split(",");
		//----------------------------------

		//retrieving info years from file.bib
		String y1 = year.replace("year={", "");
		String y2 = y1.replace("},", "");
		StringBuffer sby = new StringBuffer(y2);
		sby.deleteCharAt(sby.length() - 1);
		String finalY = sby.toString();
		String [] years = finalY.split(",");
		//----------------------------------
		
		//retrieving info titles from file.bib
		String t1 = title.replace("title={", "");
		String t2 = t1.replace("},", ",");
		StringBuffer sbt = new StringBuffer(t2);
		sbt.deleteCharAt(sbt.length() - 1);
		String finalT = sbt.toString();
		String [] titles = finalT.split(",");
		//----------------------------------
		
		//retrieving info volumes from file.bib
		String v1 = vol.replace("volume={", "");
		String v2 = v1.replace("},", ",");
		StringBuffer sbv = new StringBuffer(v2);
		sbv.deleteCharAt(sbv.length() - 1);
		String finalV = sbv.toString();
		String [] vols = finalV.split(",");
		//----------------------------------
		
		//retrieving info volumes from file.bib
		String n1 = num.replace("number={", "");
		String n2 = n1.replace("},", ",");
		StringBuffer sbn = new StringBuffer(n2);
		sbn.deleteCharAt(sbn.length() - 1);
		String finalN = sbn.toString();
		String [] nums = finalN.split(",");
		//----------------------------------
		
		//retrieving info pages from file.bib
		String p1 = pages.replace("pages={", "");
		String p2 = p1.replace("},", ",");
		StringBuffer sbp = new StringBuffer(p2);
		sbp.deleteCharAt(sbp.length() - 1);
		String finalP = sbp.toString();
		String [] pages_ = finalP.split(",");
		//----------------------------------

		PrintWriter writeFile = new PrintWriter(new FileOutputStream(ieee));

		String [] authorsIEEE = new String[authors.length];
		for(int i = 0; i < authors.length; i++) {
			authorsIEEE[i] = authors[i].replace(" * ", ", ").replace(".", ". ");
		}

		for(int i = 0; i < authors.length; i++) {
			writeFile.println(authorsIEEE[i] + "\"" + titles[i].trim() + "\"" + ", " + journals[i].trim() + ", vol. " + vols[i] + ", num. " + nums[i] + ", p. "+pages_[i] + ", " + months[i] + " "+ years[i] + ".");
		}

		writeFile.close();
		
		String [] authorsACM = new String[authors.length];
		for(int i = 0; i < authors.length; i++) {
			StringTokenizer t = new StringTokenizer(authors[i],"*");
			
			authorsACM[i] = t.nextToken().replace(".", ". ");
		}

		String acm = "ACM" + (fn + 1) + ".json";
		writeFile = new PrintWriter(new FileOutputStream(acm));

		for(int i = 0; i < authors.length; i++) {
			writeFile.println("[" + (i + 1) + "]   " + authorsACM[i] + "et al. "+ years[i] + "." + titles[i].trim()  + ". " + journals[i].trim() + 
					". " + vols[i] + ", " + nums[i] + "(" + years[i] + ")" + ", " + pages_[i] + ". " + "DOI:https://doi.org/" +dois[i] + ".");
		}
		
		writeFile.close();
		
		
		String [] authorsNJ = new String[authors.length];
		for(int i = 0; i < authors.length; i++) {
			authorsNJ[i] = authors[i].replace(" * ", " & ").replace(".", ". ");
		}
		String nj = "NJ" + (fn + 1) + ".json";
		writeFile = new PrintWriter(new FileOutputStream(nj));

		for(int i = 0; i<authors.length; i++) {
			writeFile.println(authorsNJ[i] + titles[i].trim() + ". " + " " + journals[i].trim() + " " + vols[i] + ", " + pages_[i] + "(" + years[i] + ").");
		}
		
		writeFile.close();
	}

}



