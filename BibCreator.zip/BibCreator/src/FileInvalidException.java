import java.io.FileNotFoundException;

public class FileInvalidException extends Exception {
	FileNotFoundException nf;
	public FileInvalidException() {
		super("Error: Input file cannot be parsed due to missing information to be stored in the thrown object;");
	}
	
	public FileInvalidException(FileNotFoundException nf) {
		super("Could not open input file. File does not exist; possibly it could not be created");
		this.nf = nf;
	}
	
	public FileInvalidException(String msg) {
		super(msg);
	}
}	

